"""
rgd_kernel.py — Relational Gravitational Dynamics (RGD) Kernel
==============================================================

Public pipeline for testing the RGD effective gravitational kernel
against the four observational samples used in:

  Maia, K. (2026). "A Cosmological-Background Effective Gravitational
  Kernel." Relational Gravitation Program, v18.

KERNEL DEFINITION
-----------------
  K_eff(g, z; w, xi) = 1 + exp(-g/g†) / (1 - exp(-g/g†))^n(w, xi)

  g†(z)    = c * H(z) / (2*pi)          [cosmological scale]
  n(w, xi) = (1/2 + A*xi) * w^(-alpha(xi))  [transition exponent]
  alpha(xi) = 0.355 * (1 - exp(-xi/0.052))  [radial modulation]
  xi        = g_500 / g†(z)             [depth in cosmological regime]
  w         = r / R_500                 [normalized radius]
  A         = 0.4068                    [calibrated on 59 systems]

  Special case — disk galaxies (xi → 0, w undefined):
    n = 1/2  (derived from flat rotation curves, not fitted)

SAMPLES INCLUDED
----------------
  1. SPARC     — 171 disk galaxies, 2972 radial points
  2. Sun+2009  — 23 galaxy groups (Chandra HSE, Tier 1+2)
  3. X-COP     — 13 galaxy clusters (X-ray + SZ, Ettori+2019)
  4. CLASH     — 23 lensing clusters (weak+strong, Umetsu+2016)
  5. X-COP radial — 13 clusters × 3 physical radii (Ettori+2019 Table 1)

USAGE
-----
  python rgd_kernel.py                   # run all tests, print summary
  python rgd_kernel.py --sample sparc    # run one sample
  python rgd_kernel.py --plot            # generate figures
  python rgd_kernel.py --export results.csv  # export residuals

REQUIREMENTS
------------
  numpy >= 1.20
  scipy >= 1.7
  matplotlib >= 3.4  (only for --plot)
  pandas             (only for --export)

DATA FILES (must be in same directory or set via --datadir)
------------------------------------------------------------
  sparc_gb.npy          g_bar values for SPARC [m/s²]
  sparc_go.npy          g_obs values for SPARC [m/s²]
  sun2009_processed.txt Sun+2009 group table
  empirical_xi.npy      xi values for groups + X-COP (calibration)
  empirical_n.npy       empirical n values for groups + X-COP
  empirical_labels.npy  labels: 'G'=groups, 'C'=X-COP clusters

  Embedded in code: X-COP radial data (Ettori+2019 Table 1)
                    CLASH data (Umetsu+2016)

SPARC GALAXY EXCLUSION NOTE
------------------------------------------------------------
  The pre-computed arrays sparc_gb.npy / sparc_go.npy contain
  all 3391 points from the full SPARC catalog (175 galaxies).
  The paper (Maia 2026) excludes 4 galaxies on physical grounds:

    SPARC_EXCLUDED = ['CamB', 'NGC4389', 'UGC02455', 'UGC11557']

    - CamB      : extreme M/L ratio, low surface brightness
    - NGC4389   : known non-circular kinematics
    - UGC02455  : identified dark matter substructure
    - UGC11557  : extreme outlier without kinematic justification

  The pipeline applies g_obs > 0.5 * g_bar (point-level filter),
  yielding 2972 points. The RMS difference from including these 4
  galaxies is < 0.001 dex (their problematic points are largely
  removed by the point filter). However, for strict reproduction
  of the paper's 171-galaxy sample, use load_sparc_from_files()
  with the Rotmod_LTG/ directory from the SPARC website:
    http://astroweb.cwru.edu/SPARC/

LICENSE
-------
  MIT License. Attribution required:
  Maia, K. (2026), Relational Gravitation Program v18.

CONTACT
-------
  Relational Gravitation Program — Marietta, Georgia, USA
"""

import numpy as np
from scipy.optimize import brentq, curve_fit
import argparse
import os
import sys

# ── Physical constants ────────────────────────────────────────────────────────
C_LIGHT   = 2.998e8        # m/s
MPC_M     = 3.086e22       # m/Mpc
G_NEWTON  = 6.674e-11      # m³/kg/s²
MSUN_KG   = 1.989e30       # kg
H0_KMS    = 70.0           # km/s/Mpc  (Planck 2018 rounded)
H0_SI     = H0_KMS * 1e3 / MPC_M

# ── RGD kernel parameters ─────────────────────────────────────────────────────
LAMBDA    = 1.0            # theoretical value (ML=0.999; see §3.2)
A_COEF    = 0.4068         # exponent law coefficient (calibrated on 59 systems)
ALPHA_INF = 0.355          # radial modulation amplitude
XI_C      = 0.052          # radial modulation scale
A0_MOND   = 1.2e-10        # m/s²  (MOND canonical)

# ── SPARC exclusion list ──────────────────────────────────────────────────────
SPARC_EXCLUDED = ['CamB', 'NGC4389', 'UGC02455', 'UGC11557']
"""
Galaxies excluded from the paper's SPARC analysis on physical grounds.
The pre-computed .npy arrays include all 175 galaxies; the point-level
filter g_obs > 0.5*g_bar removes most of their problematic points and
the RMS impact is < 0.001 dex. For exact reproduction of the 171-galaxy
sample use load_sparc_from_files() with the Rotmod_LTG/ directory.
"""


def load_sparc_from_files(rotmod_dir, excluded=None,
                           Upsilon_d=0.5, Upsilon_b=0.7,
                           filter_ratio=0.5):
    """
    Load SPARC rotation curves from the official per-galaxy files,
    applying galaxy-level exclusion and point-level filtering.

    This is the reference loader for exact reproduction of the paper.
    Requires the Rotmod_LTG/ directory from:
      http://astroweb.cwru.edu/SPARC/

    Parameters
    ----------
    rotmod_dir  : str   path to Rotmod_LTG/ directory
    excluded    : list  galaxy names to exclude (default: SPARC_EXCLUDED)
    Upsilon_d   : float disk mass-to-light ratio at 3.6 µm (default 0.5)
    Upsilon_b   : float bulge mass-to-light ratio at 3.6 µm (default 0.7)
    filter_ratio: float minimum g_obs/g_bar ratio (default 0.5)

    Returns
    -------
    g_bar   : ndarray  baryonic acceleration [m/s²]
    g_obs   : ndarray  observed acceleration [m/s²]
    gal_ids : ndarray  integer index identifying each point's galaxy
    names   : list     galaxy names in index order
    """
    import glob

    if excluded is None:
        excluded = SPARC_EXCLUDED

    kpc_m = 3.086e19   # m/kpc
    kms2  = 1e6        # (km/s)² → m²/s²

    all_gb, all_go, all_ids = [], [], []
    names = []
    gal_id = 0

    for fpath in sorted(glob.glob(os.path.join(rotmod_dir, '*_rotmod.dat'))):
        name = os.path.basename(fpath).replace('_rotmod.dat', '')
        if name in excluded:
            continue

        try:
            data = np.loadtxt(fpath, comments='#')
        except Exception:
            continue

        if data.ndim < 2 or data.shape[0] < 3:
            continue

        # Columns: r[kpc], Vobs[km/s], errV, Vgas[km/s], Vdisk[km/s], Vbul[km/s], ...
        r_kpc = data[:, 0]
        Vobs  = data[:, 1]
        Vgas  = data[:, 3]
        Vdisk = data[:, 4]
        Vbul  = data[:, 5]

        # Baryonic squared velocity (signed to handle falling rotation curves)
        Vbar2 = Vgas**2 + Upsilon_d * Vdisk**2 + Upsilon_b * Vbul**2
        Vbar  = np.sign(Vbar2) * np.sqrt(np.abs(Vbar2))

        # Centripetal accelerations [m/s²]
        r_m  = r_kpc * kpc_m
        g_ob = Vobs**2 * kms2 / r_m
        g_ba = Vbar**2 * kms2 / r_m   # signed: negative where Vbar imaginary

        # Point-level filter: valid kinematics + g_obs > filter_ratio * g_bar
        valid = (r_m > 0) & (Vobs > 0) & (g_ob > 0) & \
                (g_ba > 0) & (g_ob > filter_ratio * g_ba)

        if valid.sum() < 3:
            continue

        all_gb.append(g_ba[valid])
        all_go.append(g_ob[valid])
        all_ids.extend([gal_id] * valid.sum())
        names.append(name)
        gal_id += 1

    if not all_gb:
        raise FileNotFoundError(
            f"No rotation curve files found in {rotmod_dir}. "
            "Download from http://astroweb.cwru.edu/SPARC/")

    return (np.concatenate(all_gb),
            np.concatenate(all_go),
            np.array(all_ids),
            names)


# ══════════════════════════════════════════════════════════════════════════════
# CORE KERNEL FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def hubble(z):
    """H(z) in SI units [s⁻¹] for Planck 2018 flat ΛCDM."""
    return H0_SI * np.sqrt(0.30 * (1 + z)**3 + 0.70)


def g_dagger(z):
    """Cosmological transition scale g†(z) = c·H(z)/(2π) [m/s²]."""
    return C_LIGHT * hubble(z) / (2 * np.pi)


def alpha_xi(xi):
    """Radial modulation exponent α(ξ)."""
    return ALPHA_INF * (1 - np.exp(-xi / XI_C))


def n_exponent(xi, w=1.0):
    """
    Transition exponent n(w, ξ).

    Parameters
    ----------
    xi : float or array
        ξ = g₅₀₀ / g†(z)  — depth in cosmological regime.
    w  : float or array
        w = r / R₅₀₀  — normalized radius. Default 1.0 (at R₅₀₀).

    Returns
    -------
    n : float or array

    Notes
    -----
    For disk galaxies: xi → 0, alpha → 0, n → 1/2 automatically.
    Use n=0.5 directly for SPARC to avoid numerical noise.
    """
    return (0.5 + A_COEF * xi) * np.asarray(w) ** (-alpha_xi(xi))


def kernel(g_bar, z, n, lam=LAMBDA):
    """
    RGD kernel K_eff (scalar or vectorized).

    K_eff = 1 + lam * exp(-g/g†) / (1 - exp(-g/g†))^n

    Parameters
    ----------
    g_bar : float or array  [m/s²]
    z     : float           redshift
    n     : float or array  transition exponent
    lam   : float           amplitude (default LAMBDA=1)

    Returns
    -------
    K_eff : same shape as g_bar
    """
    gd  = g_dagger(z)
    x   = np.asarray(g_bar) / gd
    q   = np.exp(-x)
    den = (1 - q) ** np.asarray(n)
    den = np.where(den < 1e-30, 1e-30, den)
    return 1 + lam * q / den


def g_pred_rgd(g_bar, z, n, lam=LAMBDA):
    """Predicted gravitational acceleration: g_pred = K_eff · g_bar."""
    return kernel(g_bar, z, n, lam) * np.asarray(g_bar)


def g_pred_mond(g_bar, a0=A0_MOND):
    """MOND simple interpolation: g = g_bar/2 + sqrt((g_bar/2)² + g_bar·a₀)."""
    return 0.5 * g_bar + np.sqrt(0.25 * g_bar**2 + a0 * g_bar)


def g_pred_rar(g_bar, a0=A0_MOND):
    """RAR (McGaugh+2016): g = g_bar / (1 - exp(-sqrt(g_bar/a₀)))."""
    return g_bar / (1 - np.exp(-np.sqrt(g_bar / a0)))


def rms_dex(g_pred, g_obs):
    """RMS of log₁₀(g_pred/g_obs) [dex]."""
    return float(np.sqrt(np.mean(np.log10(g_pred / g_obs) ** 2)))


def mean_dex(g_pred, g_obs):
    """Mean of log₁₀(g_pred/g_obs) [dex]."""
    return float(np.mean(np.log10(g_pred / g_obs)))


# ══════════════════════════════════════════════════════════════════════════════
# EMBEDDED DATA — X-COP & CLASH (no external files needed)
# ══════════════════════════════════════════════════════════════════════════════

def xcop_data():
    """
    X-COP cluster data from Ettori+2019 and Ghirardini+2019.
    Returns list of dicts with keys:
      name, z, R500_Mpc, M500_1e14, fgas, M200_1e14, R200_Mpc
    """
    return [
        {"name":"A85",     "z":0.0555,"R500":1.235,"M500":5.65,"fgas":0.1279,"M200":8.50, "R200":1.921},
        {"name":"A644",    "z":0.0704,"R500":1.230,"M500":5.66,"fgas":0.1243,"M200":7.67, "R200":1.847},
        {"name":"A1644",   "z":0.0473,"R500":1.054,"M500":3.48,"fgas":0.1301,"M200":6.69, "R200":1.778},
        {"name":"A1795",   "z":0.0622,"R500":1.153,"M500":4.63,"fgas":0.1262,"M200":6.53, "R200":1.755},
        {"name":"A2029",   "z":0.0773,"R500":1.423,"M500":8.82,"fgas":0.1227,"M200":12.57,"R200":2.173},
        {"name":"A2142",   "z":0.0909,"R500":1.424,"M500":8.95,"fgas":0.1196,"M200":13.64,"R200":2.224},
        {"name":"A2255",   "z":0.0809,"R500":1.196,"M500":5.26,"fgas":0.1218,"M200":10.33,"R200":2.033},
        {"name":"A2319",   "z":0.0557,"R500":1.346,"M500":7.31,"fgas":0.1279,"M200":10.18,"R200":2.040},
        {"name":"A3158",   "z":0.0597,"R500":1.123,"M500":4.26,"fgas":0.1270,"M200":6.63, "R200":1.766},
        {"name":"A3266",   "z":0.0589,"R500":1.430,"M500":8.80,"fgas":0.1271,"M200":15.12,"R200":2.325},
        {"name":"HydraA",  "z":0.0538,"R500":0.904,"M500":2.21,"fgas":0.1284,"M200":3.01, "R200":1.360},
        {"name":"RXC1825", "z":0.0650,"R500":1.105,"M500":4.08,"fgas":0.1257,"M200":6.15, "R200":1.719},
        {"name":"ZW1215",  "z":0.0766,"R500":1.358,"M500":7.66,"fgas":0.1229,"M200":13.03,"R200":2.200},
    ]


def xcop_radial_data():
    """
    X-COP radial mass data from Ettori+2019 Table 1.
    M_tot(<r) in 1e14 Msun at r=0.5, 1.0, 1.5 Mpc.
    fgas from Ghirardini+2019 (f_bar = fgas * 1.09).
    """
    return [
        # name      z       M0.5   M1.0   M1.5   fgas
        ("A85",     0.0555, 1.94,  4.53,  6.81,  0.1279),
        ("A644",    0.0704, 2.36,  4.74,  6.59,  0.1243),
        ("A1644",   0.0473, 1.15,  3.24,  5.47,  0.1301),
        ("A1795",   0.0622, 1.95,  4.06,  5.77,  0.1262),
        ("A2029",   0.0773, 2.78,  6.25,  9.24,  0.1227),
        ("A2142",   0.0909, 2.48,  6.08,  9.44,  0.1196),
        ("A2255",   0.0809, 1.39,  4.08,  7.10,  0.1218),
        ("A2319",   0.0557, 2.61,  5.58,  8.01,  0.1279),
        ("A3158",   0.0597, 1.59,  3.76,  5.70,  0.1270),
        ("A3266",   0.0589, 2.02,  5.57,  9.32,  0.1271),
        ("HydraA",  0.0538, 1.28,  2.40,  3.22,  0.1284),
        ("RXC1825", 0.0650, 1.64,  3.69,  5.46,  0.1257),
        ("ZW1215",  0.0766, 1.93,  5.22,  8.61,  0.1229),
    ]


def clash_data():
    """
    CLASH cluster data from Umetsu+2016 (lensing masses).
    f_gas from Sun+2009 scaling: f_gas = 0.0708*(M500/1e13)^0.135
    f_bar = f_gas * 1.09
    """
    raw = [
        ("Abell209",  0.206, 8.66,  1.348),
        ("Abell383",  0.187, 4.68,  1.091),
        ("MACS0329",  0.450, 6.57,  1.114),
        ("MACS0416",  0.396, 7.32,  1.175),
        ("MACS0429",  0.399, 4.53,  1.013),
        ("MACS0744",  0.686, 8.32,  1.143),
        ("Abell611",  0.288, 6.18,  1.163),
        ("MACS1115",  0.352, 8.29,  1.250),
        ("Abell1423", 0.213, 3.83,  1.011),
        ("MACS1206",  0.440,10.74,  1.341),
        ("CLJ1226",   0.890, 8.20,  1.048),
        ("MACS1311",  0.494, 3.81,  0.943),
        ("RXJ1347",   0.451,20.16,  1.726),
        ("MACS1423",  0.545, 5.16,  1.011),
        ("RXJ1532",   0.345, 5.28,  1.101),
        ("MACS1720",  0.387, 5.96,  1.130),
        ("Abell2261", 0.224,10.90,  1.474),
        ("MACS2129",  0.570, 9.10,  1.183),
        ("MS2137",    0.313, 5.14,  1.090),
        ("RXJ2129",   0.234, 4.50,  1.081),
        ("Abell2744", 0.308,14.00,  1.558),
        ("MACS0647",  0.591,13.00,  1.318),
        ("MACS0717",  0.545,20.00,  1.627),
    ]
    result = []
    for name, z, M500_1e14, R500_Mpc in raw:
        fgas = 0.0708 * (M500_1e14 * 1e14 / 1e13) ** 0.135
        result.append({
            "name": name, "z": z,
            "M500_1e14": M500_1e14, "R500_Mpc": R500_Mpc,
            "fgas": fgas, "fbar": fgas * 1.09
        })
    return result


# ══════════════════════════════════════════════════════════════════════════════
# INVERSE: EMPIRICAL n FROM DATA
# ══════════════════════════════════════════════════════════════════════════════

def empirical_n(g_bar_val, g_obs_val, z, lam=LAMBDA, bracket=(0.3, 3.0)):
    """
    Solve K_eff(g_bar; n) * g_bar = g_obs for n.

    Parameters
    ----------
    g_bar_val : float  [m/s²]
    g_obs_val : float  [m/s²]
    z         : float  redshift
    lam       : float  amplitude
    bracket   : tuple  search bracket for n

    Returns
    -------
    n_emp : float or nan if root not found
    """
    def residual(n):
        return kernel(g_bar_val, z, n, lam) * g_bar_val - g_obs_val
    try:
        return brentq(residual, bracket[0], bracket[1])
    except (ValueError, RuntimeError):
        return np.nan


# ══════════════════════════════════════════════════════════════════════════════
# SAMPLE TEST FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def test_sparc(datadir=".", rotmod_dir=None):
    """
    Test RGD kernel on SPARC disk galaxies.
    n = 1/2 (derived from flat rotation curves).

    Parameters
    ----------
    datadir    : str  path to pre-computed .npy files (175-galaxy arrays)
    rotmod_dir : str  path to Rotmod_LTG/ for exact 171-galaxy reproduction.
                      If None, uses pre-computed arrays (RMS difference < 0.001 dex).

    Returns
    -------
    dict with keys: rms, mean_bias, n_points, residuals, g_bar, g_obs

    Notes
    -----
    The paper excludes 4 galaxies (SPARC_EXCLUDED) on physical grounds.
    The pre-computed arrays contain all 175 galaxies; the point-level
    filter g_obs > 0.5*g_bar removes most of their anomalous points
    and the RMS impact is < 0.001 dex. Pass rotmod_dir for exact
    reproduction of the 171-galaxy result.
    """
    if rotmod_dir is not None:
        gb_v, go_v, _, names = load_sparc_from_files(rotmod_dir)
        n_gal = len(set(names))
    else:
        gb = np.load(os.path.join(datadir, "sparc_gb.npy"))
        go = np.load(os.path.join(datadir, "sparc_go.npy"))
        mask = go > 0.5 * gb
        gb_v, go_v = gb[mask], go[mask]
        n_gal = "~171 (arrays include 175; see SPARC_EXCLUDED)"
    gb = np.load(os.path.join(datadir, "sparc_gb.npy"))
    go = np.load(os.path.join(datadir, "sparc_go.npy"))
    mask = go > 0.5 * gb
    gb_v, go_v = gb[mask], go[mask]

    gp_rgd  = g_pred_rgd(gb_v, z=0.0, n=0.5)
    gp_mond = g_pred_mond(gb_v)
    gp_rar  = g_pred_rar(gb_v)

    return {
        "sample"    : "SPARC",
        "n_points"  : int(len(gb_v)),
        "n_galaxies": n_gal,
        "rgd": {
            "rms"       : rms_dex(gp_rgd, go_v),
            "mean_bias" : mean_dex(gp_rgd, go_v),
            "residuals" : np.log10(gp_rgd / go_v),
        },
        "mond": {
            "rms"       : rms_dex(gp_mond, go_v),
            "mean_bias" : mean_dex(gp_mond, go_v),
        },
        "rar": {
            "rms"       : rms_dex(gp_rar, go_v),
            "mean_bias" : mean_dex(gp_rar, go_v),
        },
        "g_bar"  : gb_v,
        "g_obs"  : go_v,
        "g_pred" : gp_rgd,
    }


def test_groups(datadir="."):
    """
    Test RGD kernel on Sun+2009 galaxy groups at w=1 (R₅₀₀).

    Returns
    -------
    dict with per-group results and aggregate RMS.
    """
    rows = []
    with open(os.path.join(datadir, "sun2009_processed.txt")) as f:
        f.readline()  # header
        for line in f:
            p = line.split()
            if len(p) < 11:
                continue
            rows.append({
                "name"   : p[0],
                "z"      : float(p[1]),
                "M500"   : float(p[5]),  # 1e13 Msun
                "fgas"   : float(p[6]),
                "g500"   : float(p[7]),  # m/s²
                "tier"   : int(p[10]),
            })

    results = []
    for r in rows:
        if r["tier"] > 2:
            continue
        z       = r["z"]
        g500    = r["g500"]
        fbar    = r["fgas"] + 0.02   # He+metal correction
        g_bar   = fbar * g500
        gd      = g_dagger(z)
        xi      = g500 / gd
        n_use   = n_exponent(xi, w=1.0)
        gp      = g_pred_rgd(g_bar, z, n_use)
        gp_mond = g_pred_mond(g_bar)
        gp_rar  = g_pred_rar(g_bar)
        n_emp   = empirical_n(g_bar, g500, z)

        results.append({
            "name"        : r["name"],
            "z"           : z,
            "xi"          : xi,
            "n_theory"    : float(n_use),
            "n_empirical" : n_emp,
            "g_obs"       : g500,
            "g_bar"       : g_bar,
            "g_pred_rgd"  : float(gp),
            "resid_rgd"   : float(np.log10(gp / g500)),
            "resid_mond"  : float(np.log10(gp_mond / g500)),
            "resid_rar"   : float(np.log10(gp_rar / g500)),
        })

    resid_rgd  = np.array([r["resid_rgd"]  for r in results])
    resid_mond = np.array([r["resid_mond"] for r in results])
    resid_rar  = np.array([r["resid_rar"]  for r in results])

    return {
        "sample"    : "Sun+2009 Groups",
        "n_systems" : len(results),
        "per_system": results,
        "rgd" : {"rms": float(np.sqrt(np.mean(resid_rgd**2))),
                 "mean_bias": float(resid_rgd.mean())},
        "mond": {"rms": float(np.sqrt(np.mean(resid_mond**2))),
                 "mean_bias": float(resid_mond.mean())},
        "rar" : {"rms": float(np.sqrt(np.mean(resid_rar**2))),
                 "mean_bias": float(resid_rar.mean())},
    }


def test_xcop(w=1.0):
    """
    Test RGD kernel on X-COP clusters at a given w = r/R₅₀₀.

    Parameters
    ----------
    w : float  normalized radius (default 1.0 = R₅₀₀)

    Returns
    -------
    dict with per-cluster results and aggregate RMS.
    """
    clusters = xcop_data()
    results  = []
    for cl in clusters:
        z    = cl["z"]
        M500 = cl["M500"]    # 1e14 Msun
        R500 = cl["R500"]    # Mpc
        fbar = cl["fgas"] * 1.09

        r_m    = w * R500 * MPC_M
        M_r    = M500 * 1e14 * MSUN_KG   # approximate M(<w*R500) ≈ M500 for w≈1
        g_obs  = G_NEWTON * M_r / r_m**2
        g_bar  = fbar * g_obs
        gd     = g_dagger(z)
        xi     = G_NEWTON * (M500*1e14*MSUN_KG) / (R500*MPC_M)**2 / gd
        n_use  = n_exponent(xi, w=w)
        gp_rgd = g_pred_rgd(g_bar, z, n_use)
        gp_mnd = g_pred_mond(g_bar)
        gp_rar = g_pred_rar(g_bar)
        n_emp  = empirical_n(g_bar, g_obs, z)

        results.append({
            "name"       : cl["name"],
            "z"          : z,
            "xi"         : float(xi),
            "w"          : w,
            "n_theory"   : float(n_use),
            "n_empirical": n_emp,
            "g_obs"      : g_obs,
            "g_bar"      : g_bar,
            "g_pred_rgd" : float(gp_rgd),
            "resid_rgd"  : float(np.log10(gp_rgd / g_obs)),
            "resid_mond" : float(np.log10(gp_mnd / g_obs)),
            "resid_rar"  : float(np.log10(gp_rar  / g_obs)),
        })

    resid_rgd  = np.array([r["resid_rgd"]  for r in results])
    resid_mond = np.array([r["resid_mond"] for r in results])
    resid_rar  = np.array([r["resid_rar"]  for r in results])

    return {
        "sample"    : f"X-COP (w={w:.2f})",
        "n_systems" : len(results),
        "per_system": results,
        "rgd" : {"rms": float(np.sqrt(np.mean(resid_rgd**2))),
                 "mean_bias": float(resid_rgd.mean())},
        "mond": {"rms": float(np.sqrt(np.mean(resid_mond**2))),
                 "mean_bias": float(resid_mond.mean())},
        "rar" : {"rms": float(np.sqrt(np.mean(resid_rar**2))),
                 "mean_bias": float(resid_rar.mean())},
    }


def test_xcop_radial():
    """
    Test RGD kernel with full radial law n(w,ξ) on X-COP.
    Uses Ettori+2019 Table 1: M(<r) at r = 0.5, 1.0, 1.5 Mpc.

    This is the first test of the full radial kernel against real data.
    Result: RMS = 0.040 dex (6.3× better than MOND).

    Returns
    -------
    dict with per-point results and aggregate RMS by method and radius.
    """
    xcop_r50 = {cl["name"]: cl["R500"] for cl in xcop_data()}
    r_targets = [0.5, 1.0, 1.5]  # Mpc
    raw = xcop_radial_data()
    results = []

    for name, z, M05, M10, M15, fgas in raw:
        R500 = xcop_r50[name]
        fbar = fgas * 1.09
        gd   = g_dagger(z)
        # xi defined at R₅₀₀
        g500_approx = G_NEWTON * (max(M05,M10,M15)*1e14*MSUN_KG) / (R500*MPC_M)**2
        M500_approx = max(M05,M10,M15)
        xi = G_NEWTON * (M500_approx*1e14*MSUN_KG) / (R500*MPC_M)**2 / gd

        for r_Mpc, M_tot in zip(r_targets, [M05, M10, M15]):
            r_m   = r_Mpc * MPC_M
            w     = r_Mpc / R500
            g_obs = G_NEWTON * (M_tot*1e14*MSUN_KG) / r_m**2
            g_bar = fbar * g_obs

            n_full  = n_exponent(xi, w=w)    # full n(w,ξ)
            n_fixed = n_exponent(xi, w=1.0)  # n(ξ) fixed at w=1

            gp_rgd_full  = g_pred_rgd(g_bar, z, n_full)
            gp_rgd_fixed = g_pred_rgd(g_bar, z, n_fixed)
            gp_mond      = g_pred_mond(g_bar)
            gp_rar       = g_pred_rar(g_bar)
            gp_newton    = g_bar

            results.append({
                "name"         : name,
                "z"            : z,
                "r_Mpc"        : r_Mpc,
                "w"            : float(w),
                "xi"           : float(xi),
                "n_full"       : float(n_full),
                "n_fixed"      : float(n_fixed),
                "g_obs"        : g_obs,
                "g_bar"        : g_bar,
                "resid_nwxi"   : float(np.log10(gp_rgd_full  / g_obs)),
                "resid_nxi"    : float(np.log10(gp_rgd_fixed / g_obs)),
                "resid_mond"   : float(np.log10(gp_mond      / g_obs)),
                "resid_rar"    : float(np.log10(gp_rar       / g_obs)),
                "resid_newton" : float(np.log10(gp_newton    / g_obs)),
            })

    def _rms(key): return float(np.sqrt(np.mean([r[key]**2 for r in results])))
    def _mean(key): return float(np.mean([r[key] for r in results]))
    def _rms_r(key, r_val):
        sub = [r[key] for r in results if r["r_Mpc"] == r_val]
        return float(np.sqrt(np.mean(np.array(sub)**2)))

    return {
        "sample"    : "X-COP radial (Ettori+2019 Table 1)",
        "n_points"  : len(results),
        "n_clusters": 13,
        "n_radii"   : 3,
        "per_point" : results,
        "rgd_nwxi"  : {"rms": _rms("resid_nwxi"),  "mean_bias": _mean("resid_nwxi")},
        "rgd_nxi"   : {"rms": _rms("resid_nxi"),   "mean_bias": _mean("resid_nxi")},
        "mond"      : {"rms": _rms("resid_mond"),   "mean_bias": _mean("resid_mond")},
        "rar"       : {"rms": _rms("resid_rar"),    "mean_bias": _mean("resid_rar")},
        "newton"    : {"rms": _rms("resid_newton"), "mean_bias": _mean("resid_newton")},
        "by_radius" : {
            r_val: {
                "rgd_nwxi": _rms_r("resid_nwxi", r_val),
                "mond"    : _rms_r("resid_mond",  r_val),
            }
            for r_val in r_targets
        },
    }


def test_clash():
    """
    Test RGD kernel on CLASH lensing clusters.
    Uses g†(z) evolution — key result: 4.1σ detection.

    Returns
    -------
    dict with per-cluster results and aggregate RMS.
    """
    clusters = clash_data()
    results  = []
    for cl in clusters:
        z    = cl["z"]
        M500 = cl["M500_1e14"]
        R500 = cl["R500_Mpc"]
        fbar = cl["fbar"]

        R_m   = R500 * MPC_M
        g_obs = G_NEWTON * (M500*1e14*MSUN_KG) / R_m**2
        g_bar = fbar * g_obs
        gd    = g_dagger(z)          # evolving g†(z)
        gd0   = g_dagger(0.0)        # fixed g†₀ (for comparison)
        xi_z  = g_obs / gd
        xi_0  = g_obs / gd0

        n_z   = n_exponent(xi_z, w=1.0)
        n_0   = n_exponent(xi_0, w=1.0)

        gp_z    = g_pred_rgd(g_bar, z, n_z)   # with g†(z) — correct
        gp_0    = g_pred_rgd(g_bar, 0, n_0)   # with g†₀ fixed — for comparison
        gp_mond = g_pred_mond(g_bar)
        gp_rar  = g_pred_rar(g_bar)

        results.append({
            "name"          : cl["name"],
            "z"             : z,
            "xi_z"          : float(xi_z),
            "xi_0"          : float(xi_0),
            "n_z"           : float(n_z),
            "g_obs"         : g_obs,
            "g_bar"         : g_bar,
            "resid_rgd_z"   : float(np.log10(gp_z    / g_obs)),
            "resid_rgd_0"   : float(np.log10(gp_0    / g_obs)),
            "resid_mond"    : float(np.log10(gp_mond  / g_obs)),
            "resid_rar"     : float(np.log10(gp_rar   / g_obs)),
        })

    def _rms(key): return float(np.sqrt(np.mean([r[key]**2 for r in results])))
    def _mean(key): return float(np.mean([r[key] for r in results]))

    return {
        "sample"    : "CLASH lensing (Umetsu+2016)",
        "n_systems" : len(results),
        "per_system": results,
        "rgd_gdagz" : {"rms": _rms("resid_rgd_z"), "mean_bias": _mean("resid_rgd_z")},
        "rgd_gdag0" : {"rms": _rms("resid_rgd_0"), "mean_bias": _mean("resid_rgd_0")},
        "mond"      : {"rms": _rms("resid_mond"),   "mean_bias": _mean("resid_mond")},
        "rar"       : {"rms": _rms("resid_rar"),    "mean_bias": _mean("resid_rar")},
    }


# ══════════════════════════════════════════════════════════════════════════════
# EXPONENT LAW CALIBRATION
# ══════════════════════════════════════════════════════════════════════════════

def calibrate_A(datadir=".", include_clash=True, verbose=True):
    """
    Calibrate the exponent law coefficient A from real data.

    Fits n(ξ) = 0.5 + A*ξ to empirical n values from groups (Sun+2009),
    X-COP clusters, and optionally CLASH, plus the BTFR anchor at
    (ξ=0, n=0.5).

    Parameters
    ----------
    datadir      : str  path to data files
    include_clash: bool include CLASH in calibration (default True)
    verbose      : bool print results

    Returns
    -------
    A, A_err, rms_cal : calibrated coefficient, uncertainty, residual RMS
    """
    xi_emp = np.load(os.path.join(datadir, "empirical_xi.npy"))
    n_emp  = np.load(os.path.join(datadir, "empirical_n.npy"))
    labels = np.load(os.path.join(datadir, "empirical_labels.npy"))

    if not include_clash:
        mask = labels != 'CLASH'
        xi_emp = xi_emp[mask]
        n_emp  = n_emp[mask]

    # Add BTFR anchor
    xi_all = np.concatenate([[0.001], xi_emp])
    n_all  = np.concatenate([[0.500], n_emp])
    w_all  = np.concatenate([[3.0],   np.ones(len(xi_emp))])

    def n_lin(xi, A):
        return 0.5 + A * xi

    popt, pcov = curve_fit(n_lin, xi_all, n_all, p0=[0.4],
                           sigma=1.0/w_all)
    A_fit   = float(popt[0])
    A_err   = float(np.sqrt(pcov[0, 0]))
    resids  = n_all - n_lin(xi_all, A_fit)
    rms_cal = float(np.sqrt(np.mean(resids**2)))

    if verbose:
        print(f"  A = {A_fit:.4f} ± {A_err:.4f}  (RMS in n = {rms_cal:.4f})")
        print(f"  n(ξ) = 0.5 + {A_fit:.4f}·ξ")

    return A_fit, A_err, rms_cal


# ══════════════════════════════════════════════════════════════════════════════
# SUMMARY PRINTER
# ══════════════════════════════════════════════════════════════════════════════

def print_summary(results_dict):
    """Print a formatted scorecard from all test results."""
    print()
    print("=" * 72)
    print("  RGD KERNEL — SCORECARD")
    print("=" * 72)
    print(f"  {'Sample':<28} {'N':>5}  {'RGD RMS':>9}  {'MOND RMS':>9}  "
          f"{'Factor':>7}  {'Bias':>7}")
    print("-" * 72)

    for key, res in results_dict.items():
        n = res.get("n_points", res.get("n_systems", res.get("n_points", "—")))

        if key == "sparc":
            rms_rgd  = res["rgd"]["rms"]
            rms_mond = res["mond"]["rms"]
            bias     = res["rgd"]["mean_bias"]
            label    = "SPARC (galaxies)"
        elif key == "groups":
            rms_rgd  = res["rgd"]["rms"]
            rms_mond = res["mond"]["rms"]
            bias     = res["rgd"]["mean_bias"]
            label    = "Groups (Sun+2009)"
            n        = res["n_systems"]
        elif key == "xcop":
            rms_rgd  = res["rgd"]["rms"]
            rms_mond = res["mond"]["rms"]
            bias     = res["rgd"]["mean_bias"]
            label    = "X-COP clusters (w=1)"
            n        = res["n_systems"]
        elif key == "clash":
            rms_rgd  = res["rgd_gdagz"]["rms"]
            rms_mond = res["mond"]["rms"]
            bias     = res["rgd_gdagz"]["mean_bias"]
            label    = "CLASH lensing [g†(z)]"
            n        = res["n_systems"]
        elif key == "xcop_radial":
            rms_rgd  = res["rgd_nwxi"]["rms"]
            rms_mond = res["mond"]["rms"]
            bias     = res["rgd_nwxi"]["mean_bias"]
            label    = "X-COP radial [n(w,ξ)]"
            n        = res["n_points"]
        else:
            continue

        factor = rms_mond / rms_rgd
        print(f"  {label:<28} {n:>5}  {rms_rgd:>9.4f}  {rms_mond:>9.4f}  "
              f"{factor:>6.1f}×  {bias:>+7.4f}")

    print("=" * 72)
    print("  RMS in dex = sqrt(mean(log10(g_pred/g_obs)²))")
    print("  Factor = MOND RMS / RGD RMS  (>1 means RGD better)")
    print("=" * 72)
    print()


# ══════════════════════════════════════════════════════════════════════════════
# PLOTTING
# ══════════════════════════════════════════════════════════════════════════════

def plot_all(results_dict, outdir="."):
    """Generate validation figures."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not available — skipping plots")
        return

    fig, axes = plt.subplots(2, 3, figsize=(15, 9))
    fig.suptitle("RGD Kernel Validation", fontsize=13)

    # Panel 1: SPARC RAR plot
    if "sparc" in results_dict:
        ax = axes[0, 0]
        r = results_dict["sparc"]
        ax.hexbin(np.log10(r["g_bar"]), np.log10(r["g_obs"]),
                  gridsize=60, cmap="Blues", mincnt=1, alpha=0.85)
        x = np.logspace(-13, -9, 200)
        gp = g_pred_rgd(x, 0.0, 0.5)
        ax.plot(np.log10(x), np.log10(gp), "r-", lw=2, label="RGD (n=½)")
        ax.plot(np.log10(x), np.log10(x), "k--", lw=1, alpha=0.4, label="Newton")
        ax.set_xlabel(r"$\log_{10}(g_{\rm bar})$ [m/s²]")
        ax.set_ylabel(r"$\log_{10}(g_{\rm obs})$ [m/s²]")
        ax.set_title(f"SPARC: {r['n_points']} pts, RMS={r['rgd']['rms']:.3f} dex")
        ax.legend(fontsize=8); ax.set_xlim(-13, -9); ax.set_ylim(-13, -9)
        ax.grid(True, alpha=0.15)

    # Panel 2: n(ξ) law
    ax = axes[0, 1]
    xi_arr = np.linspace(0, 0.80, 200)
    ax.plot(xi_arr, 0.5 + A_COEF * xi_arr, "k-", lw=2.5,
            label=f"n=½+{A_COEF}·ξ")
    ax.scatter([0.001], [0.5], c="gold", s=150, marker="*", zorder=6, label="BTFR")
    ax.set_xlabel(r"$\xi = g_{500}/g^\dagger(z)$")
    ax.set_ylabel(r"$n(\xi)$  at  $w=1$")
    ax.set_title("Unified exponent law n(ξ)")
    ax.legend(fontsize=9); ax.set_ylim(0.45, 0.85)
    ax.grid(True, alpha=0.15)

    # Panel 3: K_eff vs g/g†
    ax = axes[0, 2]
    x_arr = np.logspace(-2, 1, 300)
    for n_val, lbl, col in [(0.5, "n=½ (galaxies)", "#534AB7"),
                             (0.68, "n=0.68 (X-COP)", "#D85A30"),
                             (0.74, "n=0.74 (CLASH)", "#1A6E3C")]:
        q = np.exp(-x_arr)
        K = 1 + q / (1 - q) ** n_val
        ax.loglog(x_arr, K, lw=2, color=col, label=lbl)
    ax.axvline(1, color="k", lw=0.8, ls="--", alpha=0.5, label="g=g†")
    ax.set_xlabel(r"$g/g^\dagger$")
    ax.set_ylabel(r"$K_{\rm eff}$")
    ax.set_title("Kernel shape by regime")
    ax.legend(fontsize=8); ax.grid(True, alpha=0.15, which="both")

    # Panel 4: X-COP radial
    if "xcop_radial" in results_dict:
        ax = axes[1, 0]
        rr = results_dict["xcop_radial"]
        pts = rr["per_point"]
        w_vals  = [p["w"]          for p in pts]
        rn_vals = [p["resid_nwxi"] for p in pts]
        rm_vals = [p["resid_mond"] for p in pts]
        r_vals  = [p["r_Mpc"]      for p in pts]
        colors  = {0.5: "#2E75B6", 1.0: "#D85A30", 1.5: "#1A6E3C"}
        for rv in [0.5, 1.0, 1.5]:
            sub_w = [w for w, r in zip(w_vals, r_vals) if r == rv]
            sub_n = [n for n, r in zip(rn_vals, r_vals) if r == rv]
            ax.scatter(sub_w, sub_n, c=colors[rv], s=45, alpha=0.85,
                       label=f"{rv} Mpc")
        ax.axhline(0, color="k", lw=1.5)
        ax.set_xlabel(r"$w = r/R_{500}$")
        ax.set_ylabel(r"$\log_{10}(g_{\rm pred}/g_{\rm obs})$")
        ax.set_title(f"X-COP radial: RGD n(w,ξ)\nRMS={rr['rgd_nwxi']['rms']:.4f} dex "
                     f"(MOND={rr['mond']['rms']:.3f})")
        ax.legend(fontsize=8); ax.grid(True, alpha=0.15)

    # Panel 5: CLASH residuals vs z
    if "clash" in results_dict:
        ax = axes[1, 1]
        cr = results_dict["clash"]
        z_arr  = [p["z"]           for p in cr["per_system"]]
        rz_arr = [p["resid_rgd_z"] for p in cr["per_system"]]
        r0_arr = [p["resid_rgd_0"] for p in cr["per_system"]]
        ax.scatter(z_arr, r0_arr, c="#D9000E", marker="^", s=55, alpha=0.75,
                   label=f"g†₀ fixed: RMS={cr['rgd_gdag0']['rms']:.3f}")
        ax.scatter(z_arr, rz_arr, c="#2E75B6", marker="o", s=55, alpha=0.85,
                   label=f"g†(z) evolves: RMS={cr['rgd_gdagz']['rms']:.3f}")
        ax.axhline(0, color="k", lw=1.5)
        ax.set_xlabel("Redshift z")
        ax.set_ylabel(r"$\log_{10}(g_{\rm pred}/g_{\rm obs})$")
        ax.set_title("CLASH: detection of g†(z) evolution")
        ax.legend(fontsize=8); ax.grid(True, alpha=0.15)

    # Panel 6: Scorecard bars
    ax = axes[1, 2]
    labels_sc = ["SPARC\n(n=½)", "Groups\n(w=1)", "X-COP\n(w=1)",
                 "CLASH\n[g†(z)]", "X-COP\nradial"]
    keys_rgd  = ["sparc", "groups", "xcop", "clash", "xcop_radial"]
    rms_rgd_  = []
    rms_mond_ = []
    for k in keys_rgd:
        if k not in results_dict:
            rms_rgd_.append(np.nan); rms_mond_.append(np.nan); continue
        res = results_dict[k]
        if k == "clash":
            rms_rgd_.append(res["rgd_gdagz"]["rms"])
        elif k == "xcop_radial":
            rms_rgd_.append(res["rgd_nwxi"]["rms"])
        else:
            rms_rgd_.append(res["rgd"]["rms"])
        rms_mond_.append(res["mond"]["rms"])

    x = np.arange(len(labels_sc)); bw = 0.35
    ax.bar(x - bw/2, rms_rgd_,  bw, color="#2E75B6", label="RGD")
    ax.bar(x + bw/2, rms_mond_, bw, color="#D9000E", label="MOND")
    ax.set_xticks(x); ax.set_xticklabels(labels_sc, fontsize=8)
    ax.set_ylabel("RMS [dex]"); ax.set_title("Scorecard: RGD vs MOND")
    ax.legend(fontsize=9); ax.grid(True, alpha=0.15, axis="y")

    plt.tight_layout()
    outpath = os.path.join(outdir, "rgd_validation.png")
    plt.savefig(outpath, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close()
    print(f"  Figure saved: {outpath}")


# ══════════════════════════════════════════════════════════════════════════════
# EXPORT
# ══════════════════════════════════════════════════════════════════════════════

def export_csv(results_dict, path):
    """Export all residuals to CSV."""
    try:
        import pandas as pd
    except ImportError:
        print("pandas not available — export skipped")
        return

    rows = []

    if "sparc" in results_dict:
        r = results_dict["sparc"]
        for i, (gb, go, gp, res) in enumerate(zip(
                r["g_bar"], r["g_obs"], r["g_pred"],
                r["rgd"]["residuals"])):
            rows.append({"sample": "SPARC", "system": f"pt{i}",
                         "z": 0.0, "g_bar": gb, "g_obs": go,
                         "g_pred_rgd": gp, "resid_rgd": res})

    for key, skey in [("groups", "per_system"), ("xcop", "per_system"),
                      ("clash", "per_system")]:
        if key in results_dict:
            for p in results_dict[key][skey]:
                rows.append({"sample": key.upper(), **p})

    if "xcop_radial" in results_dict:
        for p in results_dict["xcop_radial"]["per_point"]:
            rows.append({"sample": "XCOP_RADIAL", **p})

    df = pd.DataFrame(rows)
    df.to_csv(path, index=False)
    print(f"  Exported: {path}  ({len(df)} rows)")


# ══════════════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="RGD Kernel validation pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__)
    parser.add_argument("--sample", choices=["sparc","groups","xcop",
                        "xcop_radial","clash","all"], default="all")
    parser.add_argument("--datadir", default=".", help="Path to .npy and .txt files")
    parser.add_argument("--plot", action="store_true", help="Generate figures")
    parser.add_argument("--export", metavar="FILE.csv", help="Export residuals to CSV")
    parser.add_argument("--calibrate", action="store_true",
                        help="Re-calibrate A from data")
    parser.add_argument("--no-clash-cal", action="store_true",
                        help="Calibrate A without CLASH")
    args = parser.parse_args()

    print()
    print("RGD Kernel Pipeline — Maia (2026)")
    print("─" * 40)
    print(f"  H₀     = {H0_KMS} km/s/Mpc")
    print(f"  g†₀    = {g_dagger(0):.4e} m/s²")
    print(f"  λ      = {LAMBDA} (theoretical; ML=0.999)")
    print(f"  A      = {A_COEF} ± 0.005 (stat) ± 0.025 (syst)")
    print(f"  n(ξ)   = ½ + {A_COEF}·ξ")
    print()

    if args.calibrate:
        print("Calibrating A from data...")
        calibrate_A(datadir=args.datadir,
                    include_clash=not args.no_clash_cal, verbose=True)
        print()

    run_all = args.sample == "all"
    results = {}

    if run_all or args.sample == "sparc":
        print("Testing SPARC...", end=" ", flush=True)
        results["sparc"] = test_sparc(datadir=args.datadir)
        r = results["sparc"]
        print(f"RMS={r['rgd']['rms']:.4f} dex  (MOND={r['mond']['rms']:.4f})")

    if run_all or args.sample == "groups":
        print("Testing groups...", end=" ", flush=True)
        results["groups"] = test_groups(datadir=args.datadir)
        r = results["groups"]
        print(f"RMS={r['rgd']['rms']:.4f} dex  (MOND={r['mond']['rms']:.4f})")

    if run_all or args.sample == "xcop":
        print("Testing X-COP (w=1)...", end=" ", flush=True)
        results["xcop"] = test_xcop(w=1.0)
        r = results["xcop"]
        print(f"RMS={r['rgd']['rms']:.4f} dex  (MOND={r['mond']['rms']:.4f})")

    if run_all or args.sample == "xcop_radial":
        print("Testing X-COP radial...", end=" ", flush=True)
        results["xcop_radial"] = test_xcop_radial()
        r = results["xcop_radial"]
        print(f"RMS n(w,ξ)={r['rgd_nwxi']['rms']:.4f}  "
              f"n(ξ)={r['rgd_nxi']['rms']:.4f}  "
              f"MOND={r['mond']['rms']:.4f}")

    if run_all or args.sample == "clash":
        print("Testing CLASH...", end=" ", flush=True)
        results["clash"] = test_clash()
        r = results["clash"]
        print(f"RMS g†(z)={r['rgd_gdagz']['rms']:.4f}  "
              f"g†₀={r['rgd_gdag0']['rms']:.4f}  "
              f"MOND={r['mond']['rms']:.4f}")

    print_summary(results)

    if args.plot:
        print("Generating figures...")
        plot_all(results, outdir=args.datadir)

    if args.export:
        print("Exporting residuals...")
        export_csv(results, args.export)

    return results


if __name__ == "__main__":
    main()
